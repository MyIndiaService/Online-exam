-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2018 at 06:39 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'sunnygkp10@gmail.com', '123456'),
(2, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('55892169bf6a7', '55892169d2efc'),
('5589216a3646e', '5589216a48722'),
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('558922894c453', '558922895ea0a'),
('558922899ccaa', '55892289aa7cf'),
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('558973f4389ac', '558973f462e61'),
('558973f4c46f2', '558973f4d4abe'),
('558973f51600d', '558973f526fc5'),
('558973f55d269', '558973f57af07'),
('558973f5abb1a', '558973f5e764a'),
('5589751a63091', '5589751a81bf4'),
('5589751ad32b8', '5589751adbdbd'),
('5589751b304ef', '5589751b3b04d'),
('5589751b749c9', '5589751b9a98c'),
('5aafee1d80e85', '5aafee1d97dbb'),
('5aafee1dc600d', '5aafee1dcc1b7'),
('5aafee1debd8e', '5aafee1df1b50'),
('5aafee1e41710', '5aafee1e49411'),
('5aafee1e74784', '5aafee1e88008'),
('5aafee1ea7fc8', '5aafee1eb1052'),
('5aafee1ece131', '5aafee1ed71bb'),
('5aafee1f03322', '5aafee1f0b024'),
('5aafee1f2e694', '5aafee1f3677e'),
('5aafee1f5f3e0', '5aafee1f670e2'),
('5aafee1f95b04', '5aafee1f9d41e'),
('5aafee1fbdbae', '5aafee1fc3d57'),
('5aafee1fe3d17', '5aafee1fe9ad8'),
('5aafee202813c', '5aafee202defd'),
('5aafee2059658', '5aafee205f031'),
('5aafee207f7c0', '5aafee208519a'),
('5aafee20a5541', '5aafee20aab33'),
('5aafee20dbc66', '5aafee20e163f'),
('5aafee2112d98', '5aafee2118772'),
('5aafee2138f01', '5aafee2143ae4'),
('5aafee215ec82', '5aafee216465b'),
('5aafee21822f2', '5aafee21880b4'),
('5aafee21a8073', '5aafee21ae605'),
('5aafee21ce1dc', '5aafee21d3f9d'),
('5aafee21f184c', '5aafee220ace8');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('55846be776610', 'testing', 'sunnygkp10@gmail.com', 'testing', 'testing stART', '2015-06-19', '09:22:15pm'),
('5584ddd0da0ab', 'netcamp', 'sunnygkp10@gmail.com', 'feedback', ';mLBLB', '2015-06-20', '05:28:16am'),
('558510a8a1234', 'sunnygkp10', 'sunnygkp10@gmail.com', 'dl;dsnklfn', 'fmdsfld fdj', '2015-06-20', '09:05:12am'),
('5585509097ae2', 'sunny', 'sunnygkp10@gmail.com', 'kcsncsk', 'l.mdsavn', '2015-06-20', '01:37:52pm'),
('5586ee27af2c9', 'vikas', 'vikas@gmail.com', 'trial feedback', 'triaal feedbak', '2015-06-21', '07:02:31pm'),
('5589858b6c43b', 'nik', 'nik1@gmail.com', 'good', 'good site', '2015-06-23', '06:12:59pm');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('sunnygkp10@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 09:31:26'),
('sunnygkp10@gmail.com', '558920ff906b8', 4, 2, 2, 0, '2015-06-23 13:32:09'),
('avantika420@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 14:33:04'),
('avantika420@gmail.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 14:49:39'),
('sunnygkp10@gmail.com', '5589741f9ed52', 4, 5, 3, 2, '2015-06-23 15:07:16'),
('mi5@hollywood.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 15:12:56'),
('nik1@gmail.com', '558921841f1ec', 1, 2, 1, 1, '2015-06-23 16:11:50'),
('sunnygkp10@gmail.com', '5589222f16b93', 1, 2, 1, 1, '2015-06-24 03:22:38'),
('mahendra@its.co.in', '5589741f9ed52', 4, 5, 3, 2, '2018-03-19 16:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('55892169bf6a7', 'usermod', '55892169d2efc'),
('55892169bf6a7', 'useradd', '55892169d2f05'),
('55892169bf6a7', 'useralter', '55892169d2f09'),
('55892169bf6a7', 'groupmod', '55892169d2f0c'),
('5589216a3646e', '751', '5589216a48713'),
('5589216a3646e', '752', '5589216a4871a'),
('5589216a3646e', '754', '5589216a4871f'),
('5589216a3646e', '755', '5589216a48722'),
('558922117fcef', 'echo', '5589221195248'),
('558922117fcef', 'print', '558922119525a'),
('558922117fcef', 'printf', '5589221195265'),
('558922117fcef', 'cout', '5589221195270'),
('55892211e44d5', 'int a', '55892211f1f97'),
('55892211e44d5', '$a', '55892211f1fa7'),
('55892211e44d5', 'long int a', '55892211f1fb4'),
('55892211e44d5', 'int a$', '55892211f1fbd'),
('558922894c453', 'cin>>a;', '558922895ea0a'),
('558922894c453', 'cin<<a;', '558922895ea26'),
('558922894c453', 'cout>>a;', '558922895ea34'),
('558922894c453', 'cout<a;', '558922895ea41'),
('558922899ccaa', 'cout', '55892289aa7cf'),
('558922899ccaa', 'cin', '55892289aa7df'),
('558922899ccaa', 'print', '55892289aa7eb'),
('558922899ccaa', 'printf', '55892289aa7f5'),
('558923538f48d', '255.0.0.0', '558923539a46c'),
('558923538f48d', '255.255.255.0', '558923539a480'),
('558923538f48d', '255.255.0.0', '558923539a48b'),
('558923538f48d', 'none of these', '558923539a495'),
('55892353f05c4', '192.168.1.100', '5589235405192'),
('55892353f05c4', '172.168.16.2', '55892354051a3'),
('55892353f05c4', '10.0.0.0.1', '55892354051b4'),
('55892353f05c4', '11.11.11.11', '55892354051be'),
('558973f4389ac', 'containing root file-system required during bootup', '558973f462e44'),
('558973f4389ac', ' Contains only scripts to be executed during bootup', '558973f462e56'),
('558973f4389ac', ' Contains root-file system and drivers required to be preloaded during bootup', '558973f462e61'),
('558973f4389ac', 'None of the above', '558973f462e6b'),
('558973f4c46f2', 'Kernel', '558973f4d4abe'),
('558973f4c46f2', 'Shell', '558973f4d4acf'),
('558973f4c46f2', 'Commands', '558973f4d4ad9'),
('558973f4c46f2', 'Script', '558973f4d4ae3'),
('558973f51600d', 'Boot Loading', '558973f526f9d'),
('558973f51600d', ' Boot Record', '558973f526fb9'),
('558973f51600d', ' Boot Strapping', '558973f526fc5'),
('558973f51600d', ' Booting', '558973f526fce'),
('558973f55d269', ' Quick boot', '558973f57aef1'),
('558973f55d269', 'Cold boot', '558973f57af07'),
('558973f55d269', ' Hot boot', '558973f57af17'),
('558973f55d269', ' Fast boot', '558973f57af27'),
('558973f5abb1a', 'bash', '558973f5e7623'),
('558973f5abb1a', ' Csh', '558973f5e7636'),
('558973f5abb1a', ' ksh', '558973f5e7640'),
('558973f5abb1a', ' sh', '558973f5e764a'),
('5589751a63091', 'q', '5589751a81bd6'),
('5589751a63091', 'wq', '5589751a81be8'),
('5589751a63091', ' both (a) and (b)', '5589751a81bf4'),
('5589751a63091', ' none of the mentioned', '5589751a81bfd'),
('5589751ad32b8', ' moves screen down one page', '5589751adbdbd'),
('5589751ad32b8', 'moves screen up one page', '5589751adbdce'),
('5589751ad32b8', 'moves screen up one line', '5589751adbdd8'),
('5589751ad32b8', ' moves screen down one line', '5589751adbde2'),
('5589751b304ef', ' yy', '5589751b3b04d'),
('5589751b304ef', 'yw', '5589751b3b05e'),
('5589751b304ef', 'yc', '5589751b3b069'),
('5589751b304ef', ' none of the mentioned', '5589751b3b073'),
('5589751b749c9', 'X', '5589751b9a98c'),
('5589751b749c9', 'x', '5589751b9a9a5'),
('5589751b749c9', 'D', '5589751b9a9b7'),
('5589751b749c9', 'd', '5589751b9a9c9'),
('5589751bd02ec', 'autoindentation is not possible in vi editor', '5589751bdadaa'),
('5aafee1d80e85', 'Animation', '5aafee1d97dbb'),
('5aafee1d80e85', 'Color', '5aafee1d981a3'),
('5aafee1d80e85', 'Width', '5aafee1d9858b'),
('5aafee1d80e85', 'table', '5aafee1d98973'),
('5aafee1dc600d', 'Inline', '5aafee1dcb5ff'),
('5aafee1dc600d', 'Internal', '5aafee1dcb9e7'),
('5aafee1dc600d', 'External', '5aafee1dcbdcf'),
('5aafee1dc600d', 'All', '5aafee1dcc1b7'),
('5aafee1debd8e', 'Cancel', '5aafee1df1380'),
('5aafee1debd8e', 'Link the file/Url', '5aafee1df1768'),
('5aafee1debd8e', 'Submit the form data', '5aafee1df1b50'),
('5aafee1debd8e', 'None of above', '5aafee1df1f38'),
('5aafee1e41710', 'Merge Row', '5aafee1e49029'),
('5aafee1e41710', 'Merge Collumn', '5aafee1e49411'),
('5aafee1e41710', 'Both', '5aafee1e497f9'),
('5aafee1e41710', 'None', '5aafee1e49be2'),
('5aafee1e74784', 'To linking', '5aafee1e88008'),
('5aafee1e74784', 'To save', '5aafee1e883f0'),
('5aafee1e74784', 'To border Color', '5aafee1e887d8'),
('5aafee1e74784', 'None', '5aafee1e88bc0'),
('5aafee1ea7fc8', 'colspan', '5aafee1eb0c6a'),
('5aafee1ea7fc8', 'rowspan', '5aafee1eb1052'),
('5aafee1ea7fc8', 'both', '5aafee1eb143a'),
('5aafee1ea7fc8', 'none', '5aafee1eb1822'),
('5aafee1ece131', 'Single tag ', '5aafee1ed69eb'),
('5aafee1ece131', 'Pair tag', '5aafee1ed6dd3'),
('5aafee1ece131', 'both a and b', '5aafee1ed71bb'),
('5aafee1ece131', 'None', '5aafee1ed75a3'),
('5aafee1f03322', 'image tag', '5aafee1f0ac3c'),
('5aafee1f03322', 'img tag', '5aafee1f0b024'),
('5aafee1f03322', 'src tag', '5aafee1f0b40c'),
('5aafee1f03322', 'none', '5aafee1f0b7f4'),
('5aafee1f2e694', 'Order list', '5aafee1f36396'),
('5aafee1f2e694', 'Unorder list', '5aafee1f3677e'),
('5aafee1f2e694', 'both', '5aafee1f36b66'),
('5aafee1f2e694', 'Listing', '5aafee1f36f4e'),
('5aafee1f5f3e0', 'select and option', '5aafee1f670e2'),
('5aafee1f5f3e0', 'OL and LI', '5aafee1f674ca'),
('5aafee1f5f3e0', 'UL and LI', '5aafee1f678b2'),
('5aafee1f5f3e0', 'None', '5aafee1f67c9a'),
('5aafee1f95b04', '< h1 >', '5aafee1f9d41e'),
('5aafee1f95b04', '< h6 >', '5aafee1f9d806'),
('5aafee1f95b04', '< head >', '5aafee1f9dbee'),
('5aafee1f95b04', '< h3 >', '5aafee1f9dfd6'),
('5aafee1fbdbae', '< lb >', '5aafee1fc3587'),
('5aafee1fbdbae', '< break >', '5aafee1fc396f'),
('5aafee1fbdbae', '< br >', '5aafee1fc3d57'),
('5aafee1fbdbae', '< \n >', '5aafee1fc413f'),
('5aafee1fe3d17', '< body bg=\" yellow \" >', '5aafee1fe9308'),
('5aafee1fe3d17', '< background > Yellow  < / background > ', '5aafee1fe96f0'),
('5aafee1fe3d17', '<body style= \" background-color: yellow \" >', '5aafee1fe9ad8'),
('5aafee1fe3d17', '<body style= \" color: yellow \" >', '5aafee1fe9ec0'),
('5aafee202813c', 'user hint', '5aafee202defd'),
('5aafee202813c', 'autofill', '5aafee202e2e5'),
('5aafee202813c', 'validation', '5aafee202e6ce'),
('5aafee202813c', 'none', '5aafee202eab6'),
('5aafee2059658', 'Optional', '5aafee205ec49'),
('5aafee2059658', 'Compulsory ', '5aafee205f031'),
('5aafee2059658', 'both a and b', '5aafee205f419'),
('5aafee2059658', 'none', '5aafee205f801'),
('5aafee207f7c0', '< a href=\" url \" new >', '5aafee2084db2'),
('5aafee207f7c0', '< a href=\" url \" target=\"_blank\" />', '5aafee208519a'),
('5aafee207f7c0', '< a href=\" url \" target=\"new\" />', '5aafee2085582'),
('5aafee207f7c0', '< a href=\" url \" target=\"blank\" />', '5aafee208596a'),
('5aafee20a5541', '< table > < tr > < td >', '5aafee20aab33'),
('5aafee20a5541', '< table > < head > < title >', '5aafee20aaf1b'),
('5aafee20a5541', '< table > < tr > < td >', '5aafee20ab303'),
('5aafee20a5541', 'none', '5aafee20ab6eb'),
('5aafee20dbc66', '< dl >', '5aafee20e1257'),
('5aafee20dbc66', '< ol >', '5aafee20e163f'),
('5aafee20dbc66', '< ul >', '5aafee20e1a27'),
('5aafee20dbc66', '< list >', '5aafee20e1e10'),
('5aafee2112d98', '< ul >', '5aafee2118772'),
('5aafee2112d98', '< ol >', '5aafee2118b5a'),
('5aafee2112d98', '< list >', '5aafee2118f42'),
('5aafee2112d98', '< dl >', '5aafee211932a'),
('5aafee2138f01', '< input type =\" confirm password \" name= \" cpass \" />', '5aafee21436fc'),
('5aafee2138f01', '< input type =\" password \" name= \" pass \" />', '5aafee2143ae4'),
('5aafee2138f01', '< input type =\" email \" name= \" email\" />', '5aafee2143ecc'),
('5aafee2138f01', '< input type =\" number  \" name= \" number\" />', '5aafee21442b4'),
('5aafee215ec82', '< input type=\" checkbox \" />', '5aafee216465b'),
('5aafee215ec82', '< input type=\" check \" />', '5aafee2164a43'),
('5aafee215ec82', '< checkbox >', '5aafee2164e2b'),
('5aafee215ec82', '< input type=\" radio\" />', '5aafee2165214'),
('5aafee21822f2', '< input type= \"textfield\" / >', '5aafee21878e4'),
('5aafee21822f2', '< textinput type =\"text\" />', '5aafee2187ccc'),
('5aafee21822f2', '< input type= \" text\" />', '5aafee21880b4'),
('5aafee21822f2', '< textfield >', '5aafee218849c'),
('5aafee21a8073', '< input type=\"radio\" name=\" gen \" value=\"male\" / >', '5aafee21ada4d'),
('5aafee21a8073', '< input type= \"radiobutton\" name=\" male\" value=\"other\" / >', '5aafee21ade35'),
('5aafee21a8073', '< input type=\" radio\" name= \"gen\" value=\"female / >', '5aafee21ae21d'),
('5aafee21a8073', 'both a and c', '5aafee21ae605'),
('5aafee21ce1dc', 'display the information to user', '5aafee21d37cd'),
('5aafee21ce1dc', 'get input form user side', '5aafee21d3bb5'),
('5aafee21ce1dc', 'both', '5aafee21d3f9d'),
('5aafee21ce1dc', 'none', '5aafee21d4386'),
('5aafee21f184c', 'body background color', '5aafee220ace8'),
('5aafee21f184c', 'div background color', '5aafee220b0d0'),
('5aafee21f184c', 'font color', '5aafee220b4b8'),
('5aafee21f184c', 'both a and b', '5aafee220b8a0');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558920ff906b8', '55892169bf6a7', 'what is command for changing user information??', 4, 1),
('558920ff906b8', '5589216a3646e', 'what is permission for view only for other??', 4, 2),
('558921841f1ec', '558922117fcef', 'what is command for print in php??', 4, 1),
('558921841f1ec', '55892211e44d5', 'which is a variable of php??', 4, 2),
('5589222f16b93', '558922894c453', 'what is correct statement in c++??', 4, 1),
('5589222f16b93', '558922899ccaa', 'which command is use for print the output in c++?', 4, 2),
('558922ec03021', '558923538f48d', 'what is correct mask for A class IP???', 4, 1),
('558922ec03021', '55892353f05c4', 'which is not a private IP??', 4, 2),
('55897338a6659', '558973f4389ac', 'On Linux, initrd is a file', 4, 1),
('55897338a6659', '558973f4c46f2', 'Which is loaded into memory when system is booted?', 4, 2),
('55897338a6659', '558973f51600d', ' The process of starting up a computer is known as', 4, 3),
('55897338a6659', '558973f55d269', ' Bootstrapping is also known as', 4, 4),
('55897338a6659', '558973f5abb1a', 'The shell used for Single user mode shell is:', 4, 5),
('5589741f9ed52', '5589751a63091', ' Which command is used to close the vi editor?', 4, 1),
('5589741f9ed52', '5589751ad32b8', ' In vi editor, the key combination CTRL+f', 4, 2),
('5589741f9ed52', '5589751b304ef', ' Which vi editor command copies the current line of the file?', 4, 3),
('5589741f9ed52', '5589751b749c9', ' Which command is used to delete the character before the cursor location in vi editor?', 4, 4),
('5589741f9ed52', '5589751bd02ec', ' Which one of the following statement is true?', 4, 5),
('5aafe34f58156', '5aafee1d80e85', 'What is the Marquee tag?', 4, 1),
('5aafe34f58156', '5aafee1dc600d', 'Type of CSS', 4, 2),
('5aafe34f58156', '5aafee1debd8e', 'Submit button is used for ....', 4, 3),
('5aafe34f58156', '5aafee1e41710', 'Collspan Attribute is used to ......', 4, 4),
('5aafe34f58156', '5aafee1e74784', 'Ancher tag is used to ', 4, 5),
('5aafe34f58156', '5aafee1ea7fc8', 'More than two row merge by ', 4, 6),
('5aafe34f58156', '5aafee1ece131', 'Type of the html tage', 4, 7),
('5aafe34f58156', '5aafee1f03322', 'which tag is used to display the image on webpage', 4, 8),
('5aafe34f58156', '5aafee1f2e694', 'What is UL tag', 4, 9),
('5aafe34f58156', '5aafee1f5f3e0', 'which tag is used for drop down list', 4, 10),
('5aafe34f58156', '5aafee1f95b04', 'Which tag is used for large heading', 4, 11),
('5aafe34f58156', '5aafee1fbdbae', 'Which element is used for insert a line break', 4, 12),
('5aafe34f58156', '5aafee1fe3d17', 'Which tag is used for adding the background color', 4, 13),
('5aafe34f58156', '5aafee202813c', 'Placeholder attribute is used for', 4, 14),
('5aafe34f58156', '5aafee2059658', 'required attribute is used to...', 4, 15),
('5aafe34f58156', '5aafee207f7c0', 'How can you open a link in a new tab/Browser window', 4, 16),
('5aafe34f58156', '5aafee20a5541', 'Which of these elements are all < table > element', 4, 17),
('5aafe34f58156', '5aafee20dbc66', 'How can you make a numbered list', 4, 18),
('5aafe34f58156', '5aafee2112d98', 'How Can you make a bulleted list', 4, 19),
('5aafe34f58156', '5aafee2138f01', 'which tage is used for confirm password', 4, 20),
('5aafe34f58156', '5aafee215ec82', ' Which tag is used for the check box', 4, 21),
('5aafe34f58156', '5aafee21822f2', 'Which of the given correct for the input field', 4, 22),
('5aafe34f58156', '5aafee21a8073', 'Which of the given correct for the radio button group ', 4, 23),
('5aafe34f58156', '5aafee21ce1dc', 'Form tag is used to ', 4, 24),
('5aafe34f58156', '5aafee21f184c', 'bgcolor is used for..', 4, 25);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558920ff906b8', 'Linux : File Managment', 2, 1, 2, 5, '', 'linux', '2015-06-23 09:03:59'),
('558921841f1ec', 'Php Coding', 2, 1, 2, 5, '', 'PHP', '2015-06-23 09:06:12'),
('5589222f16b93', 'C++ Coding', 2, 1, 2, 5, '', 'c++', '2015-06-23 09:09:03'),
('558922ec03021', 'Networking', 2, 1, 2, 5, '', 'networking', '2015-06-23 09:12:12'),
('55897338a6659', 'Linux:startup', 2, 1, 5, 10, '', 'linux', '2015-06-23 14:54:48'),
('5589741f9ed52', 'Linux :vi Editor', 2, 1, 5, 10, '', 'linux', '2015-06-23 14:58:39'),
('5aafe34f58156', 'Html Questions', 1, 0, 25, 30, 'This the first test for html to the teqhub  some basic concept of the css', '#test1', '2018-03-19 16:20:31');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('sunnygkp10@gmail.com', 9, '2015-06-24 03:22:38'),
('avantika420@gmail.com', 8, '2015-06-23 14:49:39'),
('mi5@hollywood.com', 4, '2015-06-23 15:12:56'),
('nik1@gmail.com', 1, '2015-06-23 16:11:50'),
('mahendra@its.co.in', 4, '2018-03-19 16:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Avantika', 'F', 'KNIT sultanpur', 'avantika420@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('Mark Zukarburg', 'M', 'Stanford', 'ceo@facebook.com', 987654321, 'e10adc3949ba59abbe56e057f20f883e'),
('Komal', 'F', 'KNIT sultanpur', 'komalpd2011@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('Mahendra', 'M', 'ITS', 'mahendra@its.co.in', 9990708450, '827ccb0eea8a706c4c34a16891f84e7b'),
('Tom Cruze', 'M', 'Hollywood', 'mi5@hollywood.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('Netcamp', 'M', 'KNIT sultanpur', 'netcamp@gmail.com', 987654321, 'e10adc3949ba59abbe56e057f20f883e'),
('Nikunj', 'M', 'XYZ', 'nik1@gmail.com', 987, '202cb962ac59075b964b07152d234b70'),
('Sunny', 'M', 'KNIT sultanpur', 'sunnygkp10@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('User', 'M', 'cimt', 'user@user.com', 11, 'e10adc3949ba59abbe56e057f20f883e'),
('Vikash', 'M', 'KNIT sultanpur@gmail.com', 'vikash@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
